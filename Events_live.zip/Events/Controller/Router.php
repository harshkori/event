<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Blog
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Digital\Events\Controller;

use Magento\Framework\App\Action\Forward;
use Magento\Framework\App\ActionFactory;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\RouterInterface;
use Magento\Framework\Url;
use Digital\Events\Helper\Data;

/**
 * Class Router
 * @package Mageplaza\Blog\Controller
 */
class Router implements RouterInterface
{
    const URL_SUFFIX_RSS_XML = '.xml';
    public $actionFactory;

    public function __construct(
        ActionFactory $actionFactory,
        Data $helper
    ) {
        $this->actionFactory = $actionFactory;
        $this->helper        = $helper;
    }

    public function match(RequestInterface $request)
    {
        
        $urlSuffix = 'events';
        $identifier = trim($request->getPathInfo(), '/');
        $routePath = explode('/', $identifier);
        $routeSize = count($routePath);
        
        if (!$routeSize || ($routeSize > 3) || (array_shift($routePath) !== $urlSuffix)) {
            return null;
        }

        //echo '<br />'.$routeSize;
        //echo '<br />Before request URL: '.$request;
        
        if(strpos($identifier, 'events') == true) {
            $request->setModuleName('events')-> //module name
            setControllerName('index')-> //controller name
            setActionName('view')-> //action name
            setParam('param', 2); //custom parameters
            echo 'After: '.$request;
            
        } else {
            return false;
        }
        
        return $this->actionFactory->create(
           'Magento\Framework\App\Action\Forward',
           ['request' => $request]
       );    
        //exit;
        /*if(strpos($identifier, 'events') == true) {
            $request->setModuleName('events')-> //module name
            setControllerName('index')-> //controller name
            setActionName('view')-> //action name
            setParam('param', 2); //custom parameters
            echo 'After: '.$request;
            
        } else {
            return false;
        }*/
        // events/index/view/id/1

        /*$request = '';
        $request->setModuleName('events')-> //module name
            setControllerName('index')-> //controller name
            setActionName('view/id/1')-> //action name
            setParam('param', 2); //custom parameters
        echo '<br />After: '.$request;              
         return $this->actionFactory->create(
           'Magento\Framework\App\Action\Forward',
           ['request' => $request]
       );    
        exit;
        return $this->actionFactory->create(
            'Magento\Framework\App\Action\Forward',
            ['request' => $request]
        );*/
        

        /*$request->setModuleName($urlSuffix)
            ->setAlias(Url::REWRITE_REQUEST_PATH_ALIAS, $identifier . $urlSuffix);
        $controller = array_shift($routePath);

        if (!$controller) {
            $request->setControllerName('events')
                ->setActionName('index')
                ->setPathInfo('/events/index/view');
            return $this->actionFactory->create(Forward::class);
        }

        $action = array_shift($routePath) ?: 'index';

        if($controller) {            
            $post = $this->helper->getObjectByParam($controller, 'url_key');
            $request->setParam('id', 3); // $post->getId()
            $controller = 'index';
            $action     = 'view';
        }

        $request->setControllerName($controller)
            ->setActionName($action)
            ->setPathInfo('/events/' . $controller . '/' . $action);

        //echo '<br />request: '.$request;
        //exit;    

       
        $request->setModuleName('events')-> //module name
            setControllerName('index')-> //controller name
            setActionName('view')-> //action name
            setParam('param', 2); //custom parameters
       
       
        return $this->actionFactory->create(Forward::class);*/





        /*if (!$this->helper->isEnabled()) {
            return null;
        }

        $rssAction  = "rss.xml";
        $identifier = trim($request->getPathInfo(), '/');
        $urlSuffix  = $this->helper->getUrlSuffix();

        $routePath = explode('/', $identifier);
        $routeSize = count($routePath);
        if (!$routeSize || ($routeSize > 3) || (array_shift($routePath) !== $this->helper->getRoute())) {
            return null;
        }

        $request->setModuleName('events')
            ->setAlias(Url::REWRITE_REQUEST_PATH_ALIAS, $identifier . $urlSuffix);
        $controller = array_shift($routePath);
        if (!$controller) {
            $request->setControllerName('post')
                ->setActionName('index')
                ->setPathInfo('/events/index/view');

            return $this->actionFactory->create(Forward::class);
        }

        $action = array_shift($routePath) ?: 'index';

        if($controller) {            
            $post = $this->helper->getObjectByParam($controller, 'url_key');
            $request->setParam('id', $post->getId());
            $controller = 'index';
            $action     = 'view';
        }

        $request->setControllerName($controller)
            ->setActionName($action)
            ->setPathInfo('/events/' . $controller . '/' . $action);

        return $this->actionFactory->create(Forward::class);*/
    }

}
