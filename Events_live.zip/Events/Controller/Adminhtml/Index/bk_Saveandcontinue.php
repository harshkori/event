<?php
namespace Digital\Events\Controller\Adminhtml\Index;

class Saveandcontinue extends \Magento\Backend\App\Action
{

    const ADMIN_RESOURCE = 'Index';

    protected $resultPageFactory;
    protected $EventFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Digital\Events\Model\EventFactory $EventFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->EventFactory = $EventFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getParams();        

        if($data)
        {
            try{
                $id = $data['id'];                

                $event = $this->EventFactory->create()->load($id);

                $data = array_filter($data, function($value) {return $value !== ''; });

                $event->setData($data);
                $event->save();
                $this->messageManager->addSuccess(__('Successfully saved the item.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                //return $resultRedirect->setPath('*/*/');
                //return $resultRedirect->setPath('*/*/edit', ['id' => $event->getId()]);
                return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            }
            catch(\Exception $e)
            {
                $this->messageManager->addError($e->getMessage());
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData($data);
                //return $resultRedirect->setPath('*/*/edit', ['id' => $event->getId()]);
                return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            }
        }

         return $resultRedirect->setPath('*/*/');
         //return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
    }
}
