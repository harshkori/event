<?php
namespace Digital\Events\Controller\Index;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;


class View extends \Magento\Framework\App\Action\Action {
    
    protected $resultPageFactory;
    protected $_helper;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Digital\Events\Helper\Data $_helper,
        \Digital\Events\Model\EventFactory $eventCollection,
        PageFactory $resultPageFactory
        //\Digital\Events\Model\CollectionFactory $subscription,
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_helper = $_helper;
        $this->eventCollection = $eventCollection;
        parent::__construct($context);
    }
    
    public function execute() {
        
        /*if(!$this->_helper->isEnabled()) {
            $this->_redirect('noRoute');
            return;
        } else {
            $this->_view->loadLayout();           
            $this->_view->getPage()->getConfig()->getTitle()->set(__('Events'));          
            $resultPage = $this->resultPageFactory->create();
            return $resultPage;
        }*/
       
        if(!$this->_helper->isEnabled()) {
            return $this->_redirect('noroute');
        }

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $id = $this->getRequest()->getParam('id');

        //echo 'ID: '.$id;
        //exit;

        if(!$id){
            $this->messageManager->addError(__('Event is not available.'));
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }
        
        $eventcolle = $this->eventCollection->create()->load($id);

        /*echo '<br />ID:'.$id;
        echo '<pre>'; print_r($eventcolle->getData()); 
        exit;*/

        if(!$eventcolle->getId()){
            $this->messageManager->addError(__('Event is not available.'));
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }

        $resultPage = $this->resultPageFactory->create();
        $block = $resultPage->getLayout()->getBlock('events.eventview.view');
        if ($block) {
            $block->setRefererUrl($this->_redirect->getRefererUrl())
                ->seteventcolle($eventcolle);
        }
        return $resultPage;




    }
}