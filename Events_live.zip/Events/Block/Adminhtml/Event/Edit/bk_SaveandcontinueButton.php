<?php
namespace Digital\Events\Block\Adminhtml\Event\Edit;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Digital\Events\Block\Adminhtml\Event\Edit\GenericButton;

class SaveandcontinueButton extends GenericButton implements ButtonProviderInterface
{
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\UrlInterface $url
    ) {
       $this->request = $request;    
       $this->url = $url;   
    }
    
    public function getButtonData()
    {
        return [
            'label' => __('Save and Continue'),
            'class' => 'save-and-continue',
            'data_attribute' => [
                'mage-init' => ['button' => ['event' => 'saveandcontinue']],
                'form-role' => 'saveandcontinue',
            ],
            'on_click' => sprintf("location.href= '%s';", $this->getSaveUrl()),
            'sort_order' => 90
        ];
    }

    public function getSaveUrl()
    {
        $id = $this->request->getParam('id');

        return $this->url->getUrl('*/*/saveandcontinue', ['id' => $id]) ;
    }
}

/*use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class SaveandcontinueButton implements ButtonProviderInterface
{
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\UrlInterface $url
    ) {
       $this->request = $request;    
       $this->url = $url;   
    }

    public function getButtonData()
    {
        return [
            'label' => __('Delete Event1'),
            'on_click' => 'deleteConfirm(\'' . __('Are you sure you want to delete this event ?') . '\', \'' . $this->getDeleteUrl() . '\')',
            'class' => 'delete',
            'sort_order' => 20
        ];
    }

    public function getDeleteUrl()
    {
        
        $id = $this->request->getParam('id');
        return $this->url->getUrl('* / * /saveandcontinue', ['id' => $id]);
    }
}*/

