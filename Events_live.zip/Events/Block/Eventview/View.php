<?php
/**
*
* Do not edit or add to this file if you wish to upgrade the module to newer
* versions in the future. If you wish to customize the module for your
* needs please contact us to https://www.milople.com/contact-us.html
*
* @category    Ecommerce
* @package     Milople_Recurringandsubscriptionpayments
* @copyright   Copyright (c) 2017 Milople Technologies Pvt. Ltd. All Rights Reserved.
* @url        https://www.milople.com/magento-2-extensions/recurring-and-subscription-payments-m2.html
*
**/
namespace Digital\Events\Block\Eventview;

class View extends \Magento\Framework\View\Element\Template
{
    protected $_template = 'eventview/view.phtml';    
    protected $_customerSession;

    public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,		
		\Magento\Customer\Model\Session $customerSession,
        \Digital\Events\Model\EventFactory $eventCollection,
		array $data = []
    ) {        
        $this->_customerSession = $customerSession;  
        $this->eventCollection = $eventCollection;      
       parent::__construct($context, $data);
    }
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('My Subscriptions'));
    }
	public function getCustomer()
    {
        return $this->session->getCustomer();
    }

	public function getCollection()
    {       
        return $this->getData('collection');
    }
	
	public function getEventdata()
    {
        // $eventcolle = $this->eventCollection->create()->load($id);

        //return $this->eventCollection->load($this->getRequest()->getParam('id'));
        return $this->eventCollection->create()->load($this->getRequest()->getParam('id'));
    }
}