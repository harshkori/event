<?php

namespace Digital\Events\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

	const XML_PATH_ENABLE 	  = "eventstab/general/enable";	

    protected $httpFactory;
    protected $_storeManager;
	protected $customerSession;
	protected $inlineTranslation;
    protected $formKey;
    private $dataPersistor;
	private $postData = null;
   
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\HTTP\Adapter\FileTransferFactory $httpFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session $customerSession,
		\Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
		\Magento\Store\Model\StoreManagerInterface $storeInterface,
        \Digital\Events\Model\EventFactory $eventCollection
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->formKey = $formKey;
        $this->httpFactory = $httpFactory;
        $this->_storeManager = $storeManager;
		$this->_customerSession = $customerSession;
		$this->inlineTranslation = $inlineTranslation;
		$this->_storeInterface = $storeInterface;
        $this->eventCollection = $eventCollection;
        parent::__construct($context);
    }

    public function isEnabled() {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        return $this->scopeConfig->isSetFlag(self::XML_PATH_ENABLE,$storeScope);
    }
    
    public function getObjectByParam($value, $code = null, $type = null) {
        //$this->eventCollection->create()->load($this->getRequest()->getParam('id'));

        $object = $this->eventCollection
            ->create()
            ->load($value, $code);
        return $object;
    }

    private function getDataPersistor() {
        if ($this->dataPersistor === null) {
            $this->dataPersistor = ObjectManager::getInstance()
                ->get(DataPersistorInterface::class);
        }
        return $this->dataPersistor;
    }

    public function getFormKey() {
		return $this->formKey->getFormKey();
	}

	public function isCustomerLoggedIn() {
		return $this->_customerSession;
	}

	public function CustomerEmail() {
		return trim($this->_customerSession->getCustomer()->getEmail());
    }

	public function getBaseUrl() {
        $storeId = $this->_storeManager->getDefaultStoreView()->getStoreId();
    	$url = $this->_storeManager->getStore($storeId)->getUrl();
		return $url;
    }

    public function setMessage($status,$message) {
		$this->_customerSession->setContactMessageStatus($status);
	 	$this->_customerSession->setContactMessage($message);
	}

}