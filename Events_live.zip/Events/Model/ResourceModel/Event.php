<?php
namespace Digital\Events\Model\ResourceModel;

class Event extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('digital_events','entity_id');
    }
}