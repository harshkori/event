<?php
namespace Digital\Events\Model\Event;

use Digital\Events\Model\ResourceModel\Event\CollectionFactory;
use Digital\Events\Model\Event;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    protected $collection;
    protected $_loadedData;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $eventCollectionFactory,
        array $meta = [],
        array $data = []
    ){
        $this->collection = $eventCollectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if(isset($this->_loadedData)) {
            return $this->_loadedData;
        }

        $items = $this->collection->getItems();

        foreach($items as $event)
        {
            $this->_loadedData[$event->getId()] = $event->getData();
        }

        return $this->_loadedData;
    }

}