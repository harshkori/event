<?php
namespace Digital\Events\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Options implements ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [            
            1 => [
                'label' => 'Enable',
                'value' => 'Enable'
            ],
            2  => [
                'label' => 'Disable',
                'value' => 'Disable'
            ],            
        ];

        return $options;
    }
}
?>