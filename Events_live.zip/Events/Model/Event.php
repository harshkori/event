<?php
namespace Digital\Events\Model;
class Event extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface /* \Digital\Events\Api\Data\EventInterface, */
{
    const CACHE_TAG = 'digital_events';

    protected function _construct()
    {
        $this->_init('Digital\Events\Model\ResourceModel\Event');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}