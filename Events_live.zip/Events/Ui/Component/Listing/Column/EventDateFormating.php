<?php

namespace Digital\Events\Ui\Component\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;

class EventDateFormating extends Column {

    public function __construct(
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
    public function prepareDataSource(array $dataSource) {
        if (isset($dataSource['event_date']['items'])) {
            foreach ($dataSource['event_date']['items'] as $r => $v) {
                if(strtotime($v['event_date']) < 0){
                    $dataSource['event_date']['items'][$r]['event_date'] = "-----";
                } else{
                    $dataSource['event_date']['items'][$r]['event_date'] = date('MM/dd/Y', strtotime($v['event_date']));
                }
            }
        }
        return $dataSource;
    }
}